'use strict'

const CONSTANTS = {

  STEP_TIMEOUTS: {
    TIMEOUT: 3000
  },

  HOOK_TIMEOUTS: {
    BEFORE: 5000,
    AFTER: 5000
  }
};

module.exports = CONSTANTS;
